﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Proj_Figures
{
    public class CircleExtensions
    {
        public static int GenerateRadius(int width)//Generates the Radius from the size
        {
            return width / 2;
        }

    }
}

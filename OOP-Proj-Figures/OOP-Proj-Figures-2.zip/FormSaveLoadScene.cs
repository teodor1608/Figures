﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace OOP_Proj_Figures
{
    public partial class FormSaveLoadScene : Form
    {
        public enum Style
        {
            Load,
            Save
        }

        public FormSaveLoadScene(Style style)
        {
            InitializeComponent();
            switch (style)
            {
                case Style.Load:
                    Text = "Load Scene";
                    buttonSave.Hide();
                    break;
                case Style.Save:
                    Text = "Save Scene";
                    buttonLoad.Hide();
                    break;
            }
        }

        public List<Figure> Figures = new List<Figure>();

        public string scenePath;

        private void buttonSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();

            sfd.FileName = "myScene";
            sfd.DefaultExt = "gita";//useless ext - makes no diff
            sfd.AddExtension = true;
            sfd.Filter =
            "Gita files (*.gita)|*.gita|All files (*.*)|*.*";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string filePath = sfd.FileName;

                buttonCancel.Enabled = false;

                textBoxFileName.Text = sfd.FileName;

                scenePath = filePath;

                textBoxStatus.AppendText(Environment.NewLine + $"Saved Scene of {Figures.Count} figures at {filePath}...");

                SaveFile(filePath, Figures);
            }
        }

        public static void SaveFile(string filePath, List<Figure> fileFigures)
        {
            var formatter = new BinaryFormatter();

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                formatter.Serialize(stream, fileFigures);
            }

            /* List<string> filecontent = new List<string>(); //Old Load Deserialization using info seperated by '|' in .txt

             for (int i = 0; i < fileFigures.Count; i++)
             {

                 filecontent.Add(fileFigures[i].GetType().ToString() + '|' + fileFigures[i].Location.X + '|' + fileFigures[i].Location.Y + '|' + fileFigures[i].Width + '|' + fileFigures[i].Height + '|' + fileFigures[i].Selected + '|' + ColorTranslator.ToHtml(fileFigures[i].BackColor));
             }


             File.WriteAllLines(filePath, filecontent);*/
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            //dialog
            var ofd = new OpenFileDialog();

            ofd.Filter =
            "Gita files (*.gita)|*.gita|All files (*.*)|*.*";

            string filePath = "";
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                filePath = ofd.FileName;

                scenePath = ofd.FileName;

                textBoxFileName.Text = ofd.FileName;
            }
            //

            if (!File.Exists(filePath))
                return;

            LoadFile(filePath);

            textBoxStatus.AppendText(Environment.NewLine + $"Loaded File: {filePath}");
        }

        private void LoadFile(string filePath)
        {
            var formatter = new BinaryFormatter();

            using (var stream = new FileStream(filePath, FileMode.Open))
            {
                Figures = (List<Figure>)formatter.Deserialize(stream);
            }

            /*foreach (var figure in fileContent) //Old Load Deserialization using info seperated by '|' in .txt
            {
                var file = figure.Split('|');

                textBoxStatus.AppendText(Environment.NewLine + $"Loaded Figure: {file[0].Split('.').Last()}");

                if (file[0] == "OOP_Proj_Figures.Rectangle")
                {
                    Rectangle rect = new Rectangle();
                    Point newLocation = new Point(int.Parse(file[1]), int.Parse(file[2]));
                    rect.Location = newLocation;
                    rect.Width = int.Parse(file[3]);
                    rect.Height = int.Parse(file[4]);
                    rect.Selected = true
                        ? file[5] == "True"
                        : false;
                    rect.BackColor = ColorTranslator.FromHtml(file[6]);

                    //defs added later
                    Figures.Add(rect);
                }
                else if (file[0] == "OOP_Proj_Figures.Triangle")
                {
                    Triangle triag = new Triangle();
                    Point newLocation = new Point(int.Parse(file[1]), int.Parse(file[2]));
                    triag.Location = newLocation;
                    triag.Width = int.Parse(file[3]);
                    triag.Height = int.Parse(file[4]);
                    triag.Selected = true
                        ? file[5] == "True"
                        : false;
                    triag.BackColor = ColorTranslator.FromHtml(file[6]);

                    //defs added later
                    Figures.Add(triag);
                }
                else if (file[0] == "OOP_Proj_Figures.Circle")
                {
                    Circle circ = new Circle();
                    Point newLocation = new Point(int.Parse(file[1]), int.Parse(file[2]));
                    circ.Location = newLocation;
                    circ.Width = int.Parse(file[3]);
                    circ.Height = int.Parse(file[4]);
                    circ.Selected = true
                        ? file[5] == "True"
                        : false;
                    circ.BackColor = ColorTranslator.FromHtml(file[6]);

                    //defs added later
                    Figures.Add(circ);
                }
            }*/
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            Figures = null;
            DialogResult = DialogResult.Cancel;
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
    }
}

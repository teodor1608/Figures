﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Proj_Figures
{
    class Triangle : Figure
    {
        public event onClickDelegate onClick;

        private Point[] _points { get; set; }//Essential for drawing the triangle & the ContainsPoint method & the Intersects method
        public Point[] Points { get; set; }

        public override void Paint(Graphics g)
        {
            base.Paint(g);
        }

        public override void Move()
        {
            base.Move();
        }

        public override bool ContainsPoint(Point p)
        {
            return base.ContainsPoint(p);
        }

        public override int GetArea()
        {
            return base.GetArea();
        }

        public override bool Intersects(Figure figure)
        {
            return base.Intersects(figure);
        }

        public void GeneratePoints()//Generates corner points for the triangle from the Location and Size
        {

        }
    }
}

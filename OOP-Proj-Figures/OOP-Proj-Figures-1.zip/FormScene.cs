﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_Proj_Figures
{
    public partial class FormScene : Form
    {
        public FormScene()
        {
            InitializeComponent();
        }

        private List<Figure> _figures = new List<Figure>();
    }
}

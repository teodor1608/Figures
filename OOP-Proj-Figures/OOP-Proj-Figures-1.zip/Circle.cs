﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Proj_Figures
{
    public class Circle : Figure
    {
        public event onClickDelegate onClick;

        private int _radius { get; set; }//Essential for the ContainsPoint method & the Intersects method
        public int Radius { get; set; }

        public override void Paint(Graphics g)
        {
            base.Paint(g);
        }

        public override void Move()
        {
            base.Move();
        }

        public override bool ContainsPoint(Point p)
        {
            return base.ContainsPoint(p);
        }

        public override int GetArea()
        {
            return base.GetArea();
        }

        public override bool Intersects(Figure figure)
        {
            return base.Intersects(figure);
        }

        public void GenerateRadius()//Generates the Radius from the size
        {

        }
    }
}
